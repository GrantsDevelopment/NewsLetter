<?php
return [
    'username' => "newsletterTest-313331a8cb",
    'password' => "w~GadTZ\\ar",
    'serverAddress' => "shareddb-t.hosting.stackcp.net",
]
/*
Created by: Grant Huey on May 20th, 2020
Updated On: May 20th, 2020
My Website: http://www.grantwebdevelopment.com
*/
?>
