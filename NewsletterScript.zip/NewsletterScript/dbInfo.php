<?php
return [
    'username' => "",
    'password' => "",
    'serverAddress' => "",
]
?>